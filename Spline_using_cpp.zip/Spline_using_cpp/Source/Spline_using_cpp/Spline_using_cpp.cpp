// Fill out your copyright notice in the Description page of Project Settings.

#include "Spline_using_cpp.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Spline_using_cpp, "Spline_using_cpp" );
